# Login con Google en Flask

Implementacion de referencia de la guia web: autenticacion con Google mediante
OAuth 2.0 (flujo Authorization Code) y usuarios en SQLite.

## Puesta en marcha

1. Entorno virtual y dependencias:

   python -m venv venv
   source venv/bin/activate   # Windows: .\venv\Scripts\activate
   pip install -r requirements.txt

2. Crea un archivo .env en esta carpeta:

   GOOGLE_CLIENT_ID=tu_client_id
   GOOGLE_CLIENT_SECRET=tu_client_secret
   DATABASE=sqlite_db
   OAUTHLIB_INSECURE_TRANSPORT=1

   (El client_id y el secret salen de Google Cloud: consola -> APIs y
   servicios -> Credenciales -> ID de cliente OAuth 2.0, tipo Aplicacion web,
   con la URI de redireccion http://127.0.0.1:5000/login/callback dada de alta.)

3. Arranca la aplicacion:

   python app.py

4. Abre http://127.0.0.1:5000 y pulsa "Login with Google".

OAUTHLIB_INSECURE_TRANSPORT=1 es solo para desarrollo local con http://.
